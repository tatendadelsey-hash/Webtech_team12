/* Settings the group can change in one place. */
const CONFIG = {
  schoolName: 'Africa University',
  // BRAND: replace assets/logo.png with the official logo (keep the file name, or change it here).
  // Colours are set in css/styles.css under :root (--accent, --dark).
  logo: 'assets/logo.png',
  studentEmailDomain: 'students.school.edu',
  staffEmailDomain: 'school.edu',
  registryEmail: 'registry@school.edu',
  storageKey: 'spp.state.v1',
  sessionKey: 'spp.session.v1',
  demoPassword: 'Demo@1234',
  maxLetterChanges: 2,
  goodProjectsMin: 3,
  goodProjectsMax: 6,
  academicYears: ['2025/26', '2024/25', '2023/24'],
};
