/* Scope: who may see what.  Every request to /api/bootstrap passes through here, so a signed-in person
   only ever receives the data their role is allowed to see. The browser never has the rest. */

const roleKey = (u) => (u.role === 'staff' ? u.staffRole : u.role);          // student | teacher | lecturer | supervisor | admin
const can = (perms, u, key) => !!(perms && perms[key] && perms[key][roleKey(u)] === true);

const attachmentActive = (att) => new Date(att.end + 'T23:59:59').getTime() >= Date.now();

/* Set of student ids that this person may open. */
function visibleStudentIds(h, u, perms) {
  if (u.role === 'student') return new Set([u.id]);
  if (u.role === 'admin') return new Set(h.allUsers().filter(x => x.role === 'student').map(x => x.id));
  if (u.role === 'staff') {
    if (can(perms, u, 'view_all')) return new Set(h.allUsers().filter(x => x.role === 'student' && x.active).map(x => x.id));
    return new Set((u.teaches || []).filter(id => { const s = h.getUser(id); return s && s.active; }));
  }
  if (u.role === 'supervisor') {                                              // only linked students, only while the attachment runs
    return new Set(h.allRecords('attachments').filter(a => a.supervisorId === u.id && attachmentActive(a)).map(a => a.studentId)
      .filter(id => { const s = h.getUser(id); return s && s.active; }));
  }
  return new Set();
}

/* A user object that is safe to send: no password hash. Admins also learn if an account still needs a password. */
const publicUser = (x, asAdmin) => {
  const { hasPassword, ...rest } = x;
  if (asAdmin) rest.password = hasPassword ? 'set' : null;
  return rest;
};
/* Staff, supervisors and admins show up by name next to letters, notes and comments, so everyone gets a short directory. */
const directoryEntry = (x) => ({ id: x.id, role: x.role, staffRole: x.staffRole, name: x.name, prefix: x.prefix, title: x.title, department: x.department, unit: x.unit, photo: x.photo, active: x.active, email: '' });

function bootstrap(h, u, perms) {
  const isAdmin = u.role === 'admin';
  const vis = visibleStudentIds(h, u, perms);
  const all = h.allUsers();
  const users = [];
  all.forEach(x => {
    if (isAdmin) users.push(publicUser(x, true));
    else if (x.id === u.id || (x.role === 'student' && vis.has(x.id))) users.push(publicUser(x, false));
    else if (x.role !== 'student') users.push(directoryEntry(x));
  });

  const pick = (collection, fn) => h.allRecords(collection).filter(fn);
  const state = {
    users,
    grades: {}, projects: [], activities: [], letters: [], assessments: [], attachments: [], events: [],
    audit: [], reports: [], registry: [], signups: [],
  };
  vis.forEach(id => { const g = h.getRecord('grades', id); if (g) state.grades[id] = g; });
  state.projects = pick('projects', p => vis.has(p.userId));
  state.activities = pick('activities', a => vis.has(a.userId));

  if (u.role === 'student') {
    state.letters = pick('letters', l => l.studentId === u.id);
    state.assessments = pick('assessments', a => a.studentId === u.id);
    state.attachments = pick('attachments', a => a.studentId === u.id);
    state.events = pick('events', e => e.userId === u.id);
  } else if (u.role === 'staff') {
    state.letters = pick('letters', l => l.staffId === u.id);
    state.assessments = pick('assessments', a => a.staffId === u.id);
    state.attachments = pick('attachments', a => vis.has(a.studentId));      // lecturers can read progress notes of their students
  } else if (u.role === 'supervisor') {
    state.attachments = pick('attachments', a => a.supervisorId === u.id && attachmentActive(a));
  } else if (isAdmin) {
    state.letters = h.allRecords('letters');
    state.assessments = h.allRecords('assessments');
    state.attachments = h.allRecords('attachments');
    state.audit = h.allRecords('audit');
    state.reports = h.allRecords('reports');
    state.registry = h.db.prepare('SELECT * FROM registry').all().map(r => ({ schoolId: r.school_id, name: r.name, email: r.email, programme: r.programme, year: r.year }));
    state.signups = h.db.prepare('SELECT * FROM signups').all().map(s => ({ id: s.id, schoolId: s.school_id, name: s.name, email: s.email, registryEmail: s.registry_email, phone: s.phone, status: s.status, note: s.note, ts: s.ts }));
  }
  state.permissions = isAdmin ? h.kvGet('permissions') : {};
  return state;
}

module.exports = { roleKey, can, visibleStudentIds, attachmentActive, bootstrap, publicUser };
