/* Database: SQLite file (data/portfolio.db) using Node's built-in node:sqlite.

   Tables
   - users, signups, registry   real columns (accounts, pending sign-ups, school records)
   - records                    portfolio data stored as JSON documents, one row per item:
                                grades, projects, activities, letters, assessments, attachments, events, audit, reports
   - kv                         small settings, such as the permission matrix
   - sessions, tokens           log-in sessions and one-time links (invite / password reset)
*/
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { DatabaseSync } = require('node:sqlite');
const { hashPassword } = require('./security');

const ROOT = path.join(__dirname, '..');
const DB_FILE = process.env.DB_FILE || path.join(ROOT, 'data', 'portfolio.db');

/* The sample school database is built by seed-data.js (shared code from the prototype). We run it once to get
   plain objects, along with the permission matrix definition that the server needs for its rules. */
function loadSeedModule() {
  const cfg = fs.readFileSync(path.join(ROOT, 'public', 'js', 'config.js'), 'utf8');
  const seed = fs.readFileSync(path.join(__dirname, 'seed-data.js'), 'utf8');
  return vm.runInNewContext(`${cfg}\n${seed}\n;({ CONFIG, seed: buildSeed(), PERM_ROWS, PERM_ROLES, SCHOOL_BASELINE })`, {}, { filename: 'seed' });
}
const SHARED = loadSeedModule();   // { CONFIG, seed, PERM_ROWS, PERM_ROLES, SCHOOL_BASELINE }

function open() {
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  const db = new DatabaseSync(DB_FILE);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, role TEXT NOT NULL, staff_role TEXT, school_id TEXT UNIQUE, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      name TEXT NOT NULL, prefix TEXT, title TEXT, department TEXT, unit TEXT, programme TEXT, year INTEGER, phone TEXT, photo TEXT,
      active INTEGER NOT NULL DEFAULT 1, password_hash TEXT, teaches TEXT, profile TEXT, created_live INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS signups (
      id TEXT PRIMARY KEY, school_id TEXT NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL, registry_email TEXT, phone TEXT,
      password_hash TEXT NOT NULL, status TEXT NOT NULL, note TEXT, ts TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS registry (school_id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, programme TEXT, year INTEGER);
    CREATE TABLE IF NOT EXISTS records (collection TEXT NOT NULL, id TEXT NOT NULL, owner TEXT, data TEXT NOT NULL, PRIMARY KEY (collection, id));
    CREATE INDEX IF NOT EXISTS idx_records_owner ON records (collection, owner);
    CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, perms TEXT NOT NULL, expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS tokens (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, type TEXT NOT NULL, expires INTEGER NOT NULL);
  `);
  return db;
}

/* ---------- small helpers used everywhere ---------- */
function makeHelpers(db) {
  const tx = (fn) => {
    db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); db.exec('COMMIT'); return r; }
    catch (e) { try { db.exec('ROLLBACK'); } catch (_) {} throw e; }
  };
  const getRecord = (collection, id) => {
    const r = db.prepare('SELECT data, owner FROM records WHERE collection = ? AND id = ?').get(collection, id);
    return r ? JSON.parse(r.data) : null;
  };
  const putRecord = (collection, id, owner, obj) =>
    db.prepare('INSERT INTO records (collection, id, owner, data) VALUES (?, ?, ?, ?) ON CONFLICT(collection, id) DO UPDATE SET owner = excluded.owner, data = excluded.data')
      .run(collection, id, owner || '', JSON.stringify(obj));
  const deleteRecord = (collection, id) => db.prepare('DELETE FROM records WHERE collection = ? AND id = ?').run(collection, id);
  const allRecords = (collection) => db.prepare('SELECT data FROM records WHERE collection = ?').all(collection).map(r => JSON.parse(r.data));
  const recordsByOwner = (collection, owner) => db.prepare('SELECT data FROM records WHERE collection = ? AND owner = ?').all(collection, owner).map(r => JSON.parse(r.data));

  const rowToUser = (r) => r && ({
    id: r.id, role: r.role, staffRole: r.staff_role || undefined, schoolId: r.school_id || undefined, email: r.email, name: r.name,
    prefix: r.prefix || '', title: r.title || '', department: r.department || '', unit: r.unit || '', programme: r.programme || '',
    year: r.year || undefined, phone: r.phone || '', photo: r.photo || null, active: !!r.active,
    teaches: r.teaches ? JSON.parse(r.teaches) : undefined, profile: r.profile ? JSON.parse(r.profile) : undefined,
    createdLive: !!r.created_live, hasPassword: !!r.password_hash,
  });
  const getUser = (id) => rowToUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id));
  const allUsers = () => db.prepare('SELECT * FROM users').all().map(rowToUser);
  const insertUser = (u, passwordHash) =>
    db.prepare(`INSERT INTO users (id, role, staff_role, school_id, email, name, prefix, title, department, unit, programme, year, phone, photo, active, password_hash, teaches, profile, created_live)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(u.id, u.role, u.staffRole || null, u.schoolId || null, u.email, u.name, u.prefix || '', u.title || '', u.department || '', u.unit || '',
        u.programme || '', u.year || null, u.phone || '', u.photo || null, u.active === false ? 0 : 1, passwordHash || null,
        u.teaches ? JSON.stringify(u.teaches) : null, u.profile ? JSON.stringify(u.profile) : null, u.createdLive ? 1 : 0);
  const kvGet = (key) => { const r = db.prepare('SELECT value FROM kv WHERE key = ?').get(key); return r ? JSON.parse(r.value) : null; };
  const kvSet = (key, val) => db.prepare('INSERT INTO kv (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, JSON.stringify(val));
  return { db, tx, getRecord, putRecord, deleteRecord, allRecords, recordsByOwner, getUser, allUsers, insertUser, rowToUser, kvGet, kvSet };
}

/* ---------- seeding: fill an empty database with the sample school data ---------- */
function seed(h) {
  const { seed: S, CONFIG } = SHARED, { db } = h;
  const demoHash = hashPassword(CONFIG.demoPassword);          // every demo account shares this one hash
  h.tx(() => {
    for (const t of ['users', 'signups', 'registry', 'records', 'kv', 'sessions', 'tokens']) db.exec(`DELETE FROM ${t}`);
    S.users.forEach(u => h.insertUser(u, demoHash));
    S.registry.forEach(r => db.prepare('INSERT INTO registry VALUES (?, ?, ?, ?, ?)').run(r.schoolId, r.name, r.email, r.programme, r.year));
    S.signups.forEach(s => db.prepare('INSERT INTO signups VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(s.id, s.schoolId, s.name, s.email, s.registryEmail || null, s.phone, demoHash, s.status, s.note || '', s.ts));
    Object.entries(S.grades).forEach(([uid, sems]) => h.putRecord('grades', uid, uid, sems));
    S.projects.forEach(p => h.putRecord('projects', p.id, p.userId, p));
    S.activities.forEach(a => h.putRecord('activities', a.id, a.userId, a));
    S.letters.forEach(l => h.putRecord('letters', l.id, l.studentId, l));
    S.attachments.forEach(a => h.putRecord('attachments', a.studentId, a.studentId, a));
    S.events.forEach(e => h.putRecord('events', e.id, e.userId, e));
    S.audit.forEach(a => h.putRecord('audit', a.id, '', a));
    S.reports.forEach(r => h.putRecord('reports', r.id, '', r));
    h.kvSet('permissions', S.permissions);
  });
}

function init() {
  const db = open();
  const h = makeHelpers(db);
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count === 0 || process.argv.includes('--reset')) { seed(h); console.log('Database filled with sample data.'); }
  return h;
}

module.exports = { init, seed, makeHelpers, open, SHARED, DB_FILE };
